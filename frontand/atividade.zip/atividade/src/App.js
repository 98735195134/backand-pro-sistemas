import React from "react";
import Rotas from "./rotas";

import "./global.css";

  function App() {
  return (
     <Rotas />
  );
}
export default App;